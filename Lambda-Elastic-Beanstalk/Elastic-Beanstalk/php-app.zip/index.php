<html>
 <head>
  <title>PHP-Test</title>
 </head>
 <body>
  <?php echo '<h1>Hello all!</h1><h3>Welcome to ElasticBeanStalk</h3>'; ?>
 </body>
</html>